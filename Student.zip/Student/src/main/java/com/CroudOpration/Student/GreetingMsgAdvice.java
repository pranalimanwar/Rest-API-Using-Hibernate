package com.CroudOpration.Student;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class GreetingMsgAdvice {
	
	//@Before("execution(*com.CroudOpration.Student.StudentController.leanIOC())")
/*	@Before("execution(*com.CroudOpration.Student.StudentController.())")

	 public void printHi() {
		System.out.println("hi......");
	}
	

	
	/*@After("execution(com.CroudOpration.Student.StudentController.leanIOC())")
	 public void printbyy() {
		System.err.println("byy......");
	}*/
	

}
