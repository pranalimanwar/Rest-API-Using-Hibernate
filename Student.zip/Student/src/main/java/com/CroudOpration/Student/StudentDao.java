package com.CroudOpration.Student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;




///@Component
@Repository
public class StudentDao {
	
	@Autowired
	
	
	
	SessionFactory sessionFactory;
	
	public Student fetchStudentsInfoIntigration() {
		
		System.out.println(sessionFactory);
		
		Session session=sessionFactory.openSession();//connection
		
		Student student=session.load(Student.class,3 );//3 is primary key
		
		
		System.out.println(student);
		
		return student;
		
	}
	
	
	
	
    ArrayList<Student>fetchStudentsInfo(){
	ArrayList<Student>alStudent=new ArrayList<Student>();
		
		
try {
		
		System.out.println(1);
			//Loding a class into memmory
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println(2);
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		System.out.println(3);
		String sql ="select * from temple";
		System.out.println(4);
		Statement statement = connection.createStatement();
		System.out.println(5);
		ResultSet resultset=statement.executeQuery(sql);
		
		while (resultset.next()) {
			
		
            int id =resultset.getInt(1);
            
		    String name=resultset.getString(2);
		    
		    String gender=resultset.getString(3);
		    
		    String address=resultset.getString(4);
		    
            int percentage =resultset.getInt(5);

        	Student student=new Student( 1,"pranali","female","at virahit",86);

		    
			
        	alStudent.add(student);
		}
	}
	catch(Exception e) {
		e.printStackTrace();
		
	}
		
		return alStudent;
	}
}
