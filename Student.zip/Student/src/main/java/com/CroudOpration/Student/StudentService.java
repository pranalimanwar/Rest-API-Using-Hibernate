package com.CroudOpration.Student;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
//@Component

@Service

public class StudentService {
	
	@Autowired
	
	StudentDao studentDao;
	
	
	ArrayList<Student>fetchStudentsInfo(){
		
		ArrayList<Student>alStudenlist=new ArrayList<Student>();
		
		return alStudenlist;
	}


	public Student getStudent() {
		return studentDao.fetchStudentsInfoIntigration();
		
	}
	

}
