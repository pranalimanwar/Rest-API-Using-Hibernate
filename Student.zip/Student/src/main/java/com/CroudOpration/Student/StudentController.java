package com.CroudOpration.Student;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CroudOpration.Student.extra.A;

@RestController

public class StudentController {
	
	@Value("${studentcost}")
	int studentcost;
	
	
	
	@Autowired
	@Qualifier("creatObject")
	A aa=null;
	
	
	
	@Autowired
	X xx=null;
//Global
	
	@Autowired
	StudentService studentService=null;

	
@RequestMapping("studentcount")

int noofStudentinCity() {
	return 500000;
}


@GetMapping("checkobjectcreation")

 public void leanIOC() {
	System.out.println("studentcost>>"+studentcost);
	
	xx.m2();
}

	
@RequestMapping("addstudentinfo")

public void addStudent (@RequestBody Student student) {
	
	System.out.println("student info..."+student);
	
	
	//JDBC insert into database
	
	
	//using getmapping ,postmapping,deetmapping
}

@RequestMapping("studentinfo")

     Student fetchStudentInfo() {
	
	//class.forname
	//select*from student---column---
	
	
	
	studentService.getStudent();
	
	Student student=new Student( 1,"pranali","female","at virahit",86);
	return student;
}


@RequestMapping("studentsinfo")



    ArrayList<Student>fetchStudentsInfo(){
	
	ArrayList<Student>listStudent= studentService.fetchStudentsInfo();
	
	return listStudent;
}

@RequestMapping("studentscountbyVillage/{Villagename}")

ArrayList<String>nameofStudentinVillage(@PathVariable String Villagename ){
	
	System.out.println("I am in nameofStudentinVillage>>"+Villagename);
	
	ArrayList<String>listStudent=new ArrayList<String>();
	
	if(Villagename.equals("Virahit")) {
	
	listStudent.add("pranali");
	listStudent.add("sachin");
	listStudent.add("divya");
	listStudent.add("punam");
	listStudent.add("puja");
	}else {
		listStudent.add("pranali");
		listStudent.add("sachin");
		listStudent.add("divya");
		listStudent.add("punam");
		listStudent.add("puja");
		
	}

	return listStudent;
}


}
