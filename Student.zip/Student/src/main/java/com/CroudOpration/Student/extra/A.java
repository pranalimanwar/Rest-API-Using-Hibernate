package com.CroudOpration.Student.extra;

import org.springframework.stereotype.Component;

@Component
public class A {
	
	public A() {
		
		System.err.println("I am in extra A Constrac....");
	}
	public void mx() {
		System.out.println("I am in A...mx");
	}

}
