package com.CroudOpration.Student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.CroudOpration.Student.extra.A;

@ComponentScan("com")
@SpringBootApplication

@EnableAspectJAutoProxy

public class StudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentApplication.class, args);
	}

	@Bean
	A creatObject() {
		System.err.println("creatObject.....");
		return new A();
	}
	
	
}
