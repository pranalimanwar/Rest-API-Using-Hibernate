package com.CroudOpration.Student;

import org.springframework.stereotype.Component;

@Component
public class X {

	
X(){
	System.err.println("I am in Const....");
}

void m2() {
	
	System.err.println("X....I am in m2");
}
}
